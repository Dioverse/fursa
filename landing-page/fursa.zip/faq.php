<?php include "./header.php" ?>
    <!-- Page Header Start -->
	<div class="page-header parallaxie">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<!-- Page Header Box Start -->
					<div class="page-header-box">
						<h1 class="text-anime-style-3" data-cursor="-opaque">FAQ </h1>
						<nav class="wow fadeInUp">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="/">home</a></li>
								<li class="breadcrumb-item active" aria-current="page">FAQ</li>
							</ol>
						</nav>
					</div>
					<!-- Page Header Box End -->


				</div>
			</div>
		</div>
	</div>
    <!-- Page Header End -->

    <?php include 'faq-content.php';?>

<?php include "./footer.php" ?>